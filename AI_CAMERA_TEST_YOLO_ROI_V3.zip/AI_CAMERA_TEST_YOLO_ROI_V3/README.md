# AI_CAMERA_TEST_YOLO_ROI_V3

เวอร์ชันนี้ปรับหน้า Result ใหม่:
- แสดงภาพ ROI ที่ถูกส่งเข้า OCR
- แสดง OCR Clean แบบตัวใหญ่
- แสดง RAW, Source, Detect Confidence
- มี Badge WAIT REVIEW
- ต้องกด OK / NEXT ก่อนระบบจะไปขั้นตอนถัดไป
- STOP ยังใช้ได้เหมือนเดิม

วิธีใช้:
1. เอา `main_test_ui.py` ไปแทนของเดิมใน `/home/toto/AI_CAMERA_TEST_YOLO_ROI`
2. รัน:
   ```bash
   python3 main_test_ui.py
   ```
