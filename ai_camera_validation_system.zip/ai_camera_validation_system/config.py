import os

# =========================================================
# PATH
# =========================================================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(BASE_DIR, "output")

CAPTURE_DIR = os.path.join(OUTPUT_DIR, "captures")
CROP_DIR = os.path.join(OUTPUT_DIR, "crops")
OCR_PROCESSED_DIR = os.path.join(OUTPUT_DIR, "ocr_processed")
RESULT_JSON_DIR = os.path.join(OUTPUT_DIR, "result_json")

# =========================================================
# MODEL PATH
# =========================================================
# มีแล้ว: YOLO TOC หรือ label detection เดิม
TOC_DETECT_MODEL_PATH = os.path.join(BASE_DIR, "models", "toc_best.pt")

# ยังไม่มี: ใส่ภายหลัง
CAM1_ROI_MODEL_PATH = None   # Vendor + TOA
CAM2_ROI_MODEL_PATH = None   # TOB

# =========================================================
# CAMERA CONFIG
# =========================================================
PICAM0_INDEX = 0
PICAM1_INDEX = 1
USB_DEVICE = 0

PICAM_PREVIEW_SIZE = (640, 480)
PICAM_CAPTURE_SIZE = (1280, 720)

USB_CAPTURE_WIDTH = 1280
USB_CAPTURE_HEIGHT = 720
USB_CAPTURE_FPS = 15
USB_PREVIEW_SIZE = (480, 270)

# =========================================================
# DETECTION / TIMING
# =========================================================
PREVIEW_INTERVAL = 0.5
MOTION_THRESHOLD = 50000
STABLE_THRESHOLD = 70000
STABLE_TIME = 1.5

PICAM_FOCUS_DELAY = 4.0
REMOVE_DELAY = 1.0

YOLO_CONF_THRES = 0.40
YOLO_IMAGE_SIZE = 640
USB_STABLE_CAPTURE_DELAY = 3.0

# TOC 1 กล่อง ใส่ TOA ได้สูงสุด 6 ค่า
TOC_CAPACITY = 6

# =========================================================
# OCR CONFIG
# =========================================================
OCR_ENGINE = "easyocr"  # easyocr / halcon / paddle
ENABLE_OCR = True

OCR_ALLOWLIST = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-_."

OCR_SCALE_PI = 2
OCR_SCALE_USB = 2
OCR_SCALE_ROI = 5

# =========================================================
# MANUAL ROI FALLBACK
# ใช้ชั่วคราวตอนยังไม่มีโมเดล detect ROI
# format: x, y, w, h
# ถ้ายังไม่รู้ตำแหน่ง ให้เป็น None
# =========================================================
MANUAL_ROI = {
    "vendor": None,
    "toa": None,
    "tob": None,
    "toc": None,
}

# ใช้ ROI กลางภาพชั่วคราว ถ้าไม่มี model และไม่มี manual roi
AUTO_CENTER_ROI = True
AUTO_CENTER_ROI_RATIO = (0.50, 0.50)
