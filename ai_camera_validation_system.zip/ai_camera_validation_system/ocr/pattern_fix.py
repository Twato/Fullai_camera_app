import re

def clean_text(text):
    text = (text or "").upper()
    text = text.replace(" ", "")
    text = text.replace("-", "")
    text = text.replace("_", "")
    text = text.replace(".", "")
    text = text.replace("\n", "")
    text = text.replace("\t", "")
    return re.sub(r"[^A-Z0-9]", "", text)

DIGIT_MAP = {
    "O": "0", "Q": "0", "D": "0",
    "I": "1", "L": "1",
    "S": "5",
    "B": "8",
    "A": "4",
    "Z": "2",
    "G": "6",
}

LETTER_MAP = {
    "0": "O",
    "1": "I",
    "5": "S",
    "8": "B",
    "2": "Z",
    "6": "G",
}

def force_digit(ch):
    ch = ch.upper()
    if ch.isdigit():
        return ch
    return DIGIT_MAP.get(ch, ch)

def force_letter(ch):
    ch = ch.upper()
    if ch.isalpha():
        return ch
    return LETTER_MAP.get(ch, ch)

def force_hex(ch):
    ch = ch.upper()
    if ch in "0123456789ABCDEF":
        return ch
    mapped = DIGIT_MAP.get(ch, ch)
    if mapped in "0123456789ABCDEF":
        return mapped
    return ch

def fit_pattern(text, kinds):
    text = clean_text(text)

    if len(text) > len(kinds):
        text = text[:len(kinds)]

    if len(text) < len(kinds):
        return text, False

    out = []

    for ch, kind in zip(text, kinds):
        if kind == "digit":
            out.append(force_digit(ch))
        elif kind == "letter":
            out.append(force_letter(ch))
        elif kind == "hex":
            out.append(force_hex(ch))
        elif kind == "fixed_K":
            out.append("K")
        elif kind == "fixed_C":
            out.append("C")
        elif kind == "fixed_U":
            out.append("U")
        elif kind == "any":
            out.append(ch.upper())
        else:
            out.append(ch.upper())

    fixed = "".join(out)
    return fixed, True

def fix_delivery_no(text):
    """
    ตัวอย่าง:
    0801189710 = 10 digit
    I9011789 = I + 7 digit หรือบางงานอาจเป็น 8 ตัว
    """
    t = clean_text(text)

    if len(t) == 10:
        fixed, ok = fit_pattern(t, ["digit"] * 10)
        return fixed, bool(re.match(r"^[0-9]{10}$", fixed))

    if len(t) == 8:
        # I9011789
        first = t[0]
        if first in ["1", "L"]:
            first = "I"
        elif first in ["I"]:
            first = "I"
        rest, _ = fit_pattern(t[1:], ["digit"] * 7)
        fixed = first + rest
        return fixed, bool(re.match(r"^[I][0-9]{7}$", fixed))

    return t, False

def fix_lot_toa(text):
    # 621U2K0000
    kinds = ["digit", "digit", "digit", "fixed_U", "digit", "fixed_K", "hex", "hex", "hex", "hex"]
    fixed, ok = fit_pattern(text, kinds)
    return fixed, ok and bool(re.match(r"^[0-9]{3}U[1-7]K[0-9A-F]{4}$", fixed))

def fix_lot_tob(text):
    # 621U2C0000
    kinds = ["digit", "digit", "digit", "fixed_U", "digit", "fixed_C", "hex", "hex", "hex", "hex"]
    fixed, ok = fit_pattern(text, kinds)
    return fixed, ok and bool(re.match(r"^[0-9]{3}U[1-7]C[0-9A-F]{4}$", fixed))

def fix_date_code(text):
    # ยังไม่แน่ใจ pattern จริง ใช้แบบ 8 ตัวก่อน เช่น 618U3003
    # บังคับตัวที่ 4 เป็น U และตัวอื่นพยายามเป็น digit/hex
    kinds = ["digit", "digit", "digit", "fixed_U", "digit", "hex", "hex", "hex"]
    fixed, ok = fit_pattern(text, kinds)
    return fixed, ok and bool(re.match(r"^[0-9]{3}U[0-9][0-9A-F]{3}$", fixed))

def fix_box_id(text):
    # LT41T25C190063 ยังไม่แน่ใจ pattern
    # ใช้ clean ก่อน และ validate ความยาวคร่าว ๆ
    fixed = clean_text(text)
    return fixed, len(fixed) >= 8

def fix_by_field(field_name, raw_text):
    if field_name == "delivery_no":
        return fix_delivery_no(raw_text)
    if field_name == "toa_lot":
        return fix_lot_toa(raw_text)
    if field_name == "tob_lot":
        return fix_lot_tob(raw_text)
    if field_name == "date_code":
        return fix_date_code(raw_text)
    if field_name == "box_id":
        return fix_box_id(raw_text)
    return clean_text(raw_text), False
