import easyocr

class EasyOCREngine:
    def __init__(self, allowlist):
        self.allowlist = allowlist
        self.reader = None

    def load(self):
        if self.reader is None:
            self.reader = easyocr.Reader(["en"], gpu=False)

    def read(self, image):
        self.load()

        results = self.reader.readtext(
            image,
            allowlist=self.allowlist,
            detail=1,
            paragraph=False,
            decoder="beamsearch"
        )

        raw_final = ""
        items = []

        for bbox, text, conf in results:
            raw_final += text
            items.append({
                "text": text,
                "conf": float(conf)
            })

        return {
            "raw": raw_final,
            "items": items
        }
