class PaddleOCREngine:
    """
    Placeholder สำหรับ PaddleOCR
    ตอนนี้เก็บไว้ก่อนตามแผน
    """
    def __init__(self):
        pass

    def read(self, image):
        return {
            "raw": "",
            "items": [],
            "status": "paddle_not_ready"
        }
