class HalconOCREngine:
    """
    Placeholder สำหรับ HALCON OCR
    ภายหลังให้ return:
    {
        "raw": "621U2K0000",
        "items": [{"text": "...", "conf": 0.99}]
    }
    """
    def __init__(self):
        pass

    def read(self, image):
        return {
            "raw": "",
            "items": [],
            "status": "halcon_not_ready"
        }
