import os
import cv2
import numpy as np

from config import (
    CROP_DIR,
    OCR_PROCESSED_DIR,
    OCR_ALLOWLIST,
    OCR_SCALE_ROI,
    MANUAL_ROI,
    AUTO_CENTER_ROI,
    AUTO_CENTER_ROI_RATIO,
    YOLO_CONF_THRES,
    YOLO_IMAGE_SIZE,
    CAM1_ROI_MODEL_PATH,
    CAM2_ROI_MODEL_PATH,
    TOC_DETECT_MODEL_PATH,
    OCR_ENGINE
)

from detection.yolo_detector import YoloDetector
from ocr.ocr_engine_easyocr import EasyOCREngine
from ocr.ocr_engine_halcon import HalconOCREngine
from ocr.ocr_engine_paddle import PaddleOCREngine
from ocr.pattern_fix import fix_by_field

_detectors = {}
_ocr_engine = None

LABEL_GROUP_CONFIG = {
    # Camera 1 ภาพเดียวมี vendor + toa
    "vendor_toa": {
        "model_path": CAM1_ROI_MODEL_PATH,
        "expected": {
            "vendor_box_id": {
                "label_name": "vendor_box_id",
                "fallback_roi_key": "vendor",
                "field": "box_id"
            },
            "vendor_date_code": {
                "label_name": "vendor_date_code",
                "fallback_roi_key": "vendor",
                "field": "date_code"
            },
            "toa_lot": {
                "label_name": "toa_lot",
                "fallback_roi_key": "toa",
                "field": "toa_lot"
            },
            "toa_date_code": {
                "label_name": "toa_date_code",
                "fallback_roi_key": "toa",
                "field": "date_code"
            },
        }
    },

    # Camera 2
    "tob": {
        "model_path": CAM2_ROI_MODEL_PATH,
        "expected": {
            "tob_lot": {
                "label_name": "tob_lot",
                "fallback_roi_key": "tob",
                "field": "tob_lot"
            },
            "tob_date_code": {
                "label_name": "tob_date_code",
                "fallback_roi_key": "tob",
                "field": "date_code"
            },
        }
    },

    # Camera 3
    "toc": {
        "model_path": TOC_DETECT_MODEL_PATH,
        "expected": {
            "toc_delivery_no": {
                "label_name": "toc_delivery_no",
                "fallback_roi_key": "toc",
                "field": "delivery_no"
            },
            # TOC อาจมี LOT หลายค่าใน ROI เดียว
            "toc_lot": {
                "label_name": "toc_lot",
                "fallback_roi_key": "toc",
                "field": "toa_lot"
            },
        }
    }
}

def get_detector(label_group):
    if label_group not in LABEL_GROUP_CONFIG:
        return None

    model_path = LABEL_GROUP_CONFIG[label_group]["model_path"]

    if model_path is None:
        return None

    key = label_group

    if key not in _detectors:
        _detectors[key] = YoloDetector(
            model_path=model_path,
            conf=YOLO_CONF_THRES,
            imgsz=YOLO_IMAGE_SIZE
        )

    return _detectors[key]

def get_ocr_engine():
    global _ocr_engine

    if _ocr_engine is not None:
        return _ocr_engine

    if OCR_ENGINE == "easyocr":
        _ocr_engine = EasyOCREngine(OCR_ALLOWLIST)
    elif OCR_ENGINE == "halcon":
        _ocr_engine = HalconOCREngine()
    elif OCR_ENGINE == "paddle":
        _ocr_engine = PaddleOCREngine()
    else:
        _ocr_engine = EasyOCREngine(OCR_ALLOWLIST)

    return _ocr_engine

def center_roi(image):
    h, w = image.shape[:2]
    rw, rh = AUTO_CENTER_ROI_RATIO
    roi_w = int(w * rw)
    roi_h = int(h * rh)
    x = int((w - roi_w) / 2)
    y = int((h - roi_h) / 2)
    return [x, y, roi_w, roi_h]

def crop_xywh(image, roi):
    x, y, w, h = roi
    ih, iw = image.shape[:2]
    x = max(0, int(x))
    y = max(0, int(y))
    w = max(1, int(w))
    h = max(1, int(h))
    x2 = min(iw, x + w)
    y2 = min(ih, y + h)
    return image[y:y2, x:x2], [x, y, x2, y2]

def crop_xyxy(image, box):
    x1, y1, x2, y2 = box
    ih, iw = image.shape[:2]
    x1 = max(0, int(x1))
    y1 = max(0, int(y1))
    x2 = min(iw, int(x2))
    y2 = min(ih, int(y2))
    return image[y1:y2, x1:x2], [x1, y1, x2, y2]

def preprocess_for_ocr(crop):
    if crop is None or crop.size == 0:
        return None

    gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)

    gray = cv2.resize(
        gray,
        None,
        fx=OCR_SCALE_ROI,
        fy=OCR_SCALE_ROI,
        interpolation=cv2.INTER_CUBIC
    )

    gray = cv2.convertScaleAbs(gray, alpha=1.25, beta=5)

    sharpen_kernel = np.array([
        [0, -0.5, 0],
        [-0.5, 3, -0.5],
        [0, -0.5, 0]
    ], dtype=np.float32)

    gray = cv2.filter2D(gray, -1, sharpen_kernel)

    return gray

def find_detection_for_label(detections, label_name):
    matched = [d for d in detections if d["name"] == label_name]

    if not matched:
        return None

    matched = sorted(matched, key=lambda d: d["conf"], reverse=True)
    return matched[0]

def run_single_field_ocr(image, image_stem, field_key, cfg, detections):
    label_name = cfg["label_name"]
    fallback_roi_key = cfg["fallback_roi_key"]
    field = cfg["field"]

    det = find_detection_for_label(detections, label_name)

    source = "none"
    conf = None
    box = None

    if det is not None:
        crop, box = crop_xyxy(image, det["box"])
        source = "model"
        conf = det["conf"]

    else:
        roi = MANUAL_ROI.get(fallback_roi_key)
        if roi is not None:
            crop, box = crop_xywh(image, roi)
            source = "manual_roi"
        elif AUTO_CENTER_ROI:
            crop, box = crop_xywh(image, center_roi(image))
            source = "auto_center_roi"
        else:
            crop = None

    if crop is None or crop.size == 0:
        return {
            "ready": False,
            "source": source,
            "raw": "",
            "fixed": "",
            "valid": False,
            "box": box,
            "detect_conf": conf,
            "error": "no_roi"
        }

    crop_name = f"{image_stem}_{field_key}_crop.jpg"
    crop_path = os.path.join(CROP_DIR, crop_name)
    cv2.imwrite(crop_path, crop)

    processed = preprocess_for_ocr(crop)
    processed_path = os.path.join(OCR_PROCESSED_DIR, f"{image_stem}_{field_key}_processed.jpg")
    if processed is not None:
        cv2.imwrite(processed_path, processed)

    ocr = get_ocr_engine().read(processed)
    raw = ocr.get("raw", "")

    fixed, valid = fix_by_field(field, raw)

    return {
        "ready": True,
        "source": source,
        "raw": raw,
        "fixed": fixed,
        "valid": valid,
        "box": box,
        "detect_conf": conf,
        "crop_path": crop_path,
        "processed_path": processed_path,
        "ocr_items": ocr.get("items", [])
    }

def run_label_ocr(image_path, label_group):
    if not os.path.exists(image_path):
        return {
            "ok": False,
            "error": "image_not_found",
            "image_path": image_path
        }

    image = cv2.imread(image_path)

    if image is None:
        return {
            "ok": False,
            "error": "cannot_read_image",
            "image_path": image_path
        }

    image_stem = os.path.splitext(os.path.basename(image_path))[0]

    group_cfg = LABEL_GROUP_CONFIG.get(label_group)
    if group_cfg is None:
        return {
            "ok": False,
            "error": "unknown_label_group",
            "label_group": label_group
        }

    detector = get_detector(label_group)
    if detector is not None and detector.ready:
        detections = detector.detect_best_by_class(image)
        detector_status = "model"
    else:
        detections = []
        detector_status = "not_ready_use_fallback_roi"

    fields = {}

    for field_key, cfg in group_cfg["expected"].items():
        fields[field_key] = run_single_field_ocr(
            image=image,
            image_stem=image_stem,
            field_key=field_key,
            cfg=cfg,
            detections=detections
        )

    ok = all(v.get("valid", False) for v in fields.values())

    return {
        "ok": ok,
        "image_path": image_path,
        "label_group": label_group,
        "detector_status": detector_status,
        "detections": detections,
        "fields": fields
    }
