import os
import json
import threading
from time import sleep
import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import cv2

from config import (
    CAPTURE_DIR,
    CROP_DIR,
    OCR_PROCESSED_DIR,
    RESULT_JSON_DIR,
    PICAM0_INDEX,
    PICAM1_INDEX,
    USB_DEVICE,
    USB_PREVIEW_SIZE,
    PREVIEW_INTERVAL,
    REMOVE_DELAY
)

from utils import ensure_dirs, timestamp_name
from camera.pi_camera_controller import PiCameraController
from camera.usb_camera_controller import UsbCameraController
from ocr.roi_ocr_pipeline import run_label_ocr
from validation.delivery_context import DeliveryContext
from validation.memory_store import MemoryStore
from validation.validator import Validator

ensure_dirs(CAPTURE_DIR, CROP_DIR, OCR_PROCESSED_DIR, RESULT_JSON_DIR)

running = False
last_preview_time = 0
current_controller = None

def set_status(text):
    try:
        status_label.config(text=text)
        root.update_idletasks()
    except Exception:
        pass
    print(text)

def update_preview(frame, is_bgr=False):
    global last_preview_time

    import time
    now = time.time()
    if now - last_preview_time < PREVIEW_INTERVAL:
        return

    last_preview_time = now

    try:
        display = cv2.resize(frame, USB_PREVIEW_SIZE)

        if is_bgr:
            display = cv2.cvtColor(display, cv2.COLOR_BGR2RGB)

        img = Image.fromarray(display)
        imgtk = ImageTk.PhotoImage(image=img)

        preview_label.imgtk = imgtk
        preview_label.config(image=imgtk)

    except Exception as e:
        print("Preview Error:", e)

def save_json(name, data):
    path = os.path.join(RESULT_JSON_DIR, name)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    return path

def capture_path(prefix):
    return os.path.join(CAPTURE_DIR, timestamp_name(prefix, "jpg"))

def parse_box_ids(text):
    """
    ใส่ได้ทั้ง:
    BOX001,BOX002,BOX003
    หรือขึ้นบรรทัดใหม่
    """
    raw = text.replace("\n", ",")
    return [x.strip() for x in raw.split(",") if x.strip()]

def process_one_product(index, ctx, validator):
    global current_controller

    set_status(f"Product {index + 1}/{ctx.quantity}: Start Camera 1")

    cam1_path = capture_path(f"cam1_vendor_toa_p{index+1}")
    cam2_path = capture_path(f"cam2_tob_p{index+1}")

    # =====================================================
    # Camera 1: Background Change Detect + Capture
    # =====================================================
    cam1 = PiCameraController(
        camera_index=PICAM0_INDEX,
        name="Camera 1 Vendor+TOA",
        status_cb=set_status,
        preview_cb=update_preview
    )
    current_controller = cam1

    try:
        cam1.open()
        bg = cam1.wait_background_stable(lambda: running)
        if bg is None:
            return False

        detected = cam1.wait_object_by_background(bg, lambda: running)
        if not detected:
            return False

        cam1.autofocus_delay(lambda: running)
        cam1.capture_file(cam1_path)
    finally:
        cam1.close()
        current_controller = None

    # =====================================================
    # Camera 2: เปิดแล้วถ่ายทันที
    # =====================================================
    if not running:
        return False

    set_status(f"Product {index + 1}/{ctx.quantity}: Start Camera 2")

    cam2 = PiCameraController(
        camera_index=PICAM1_INDEX,
        name="Camera 2 TOB",
        status_cb=set_status,
        preview_cb=update_preview
    )
    current_controller = cam2

    try:
        cam2.open()
        cam2.autofocus_delay(lambda: running)
        cam2.capture_file(cam2_path)
    finally:
        cam2.close()
        current_controller = None

    # =====================================================
    # OCR after both images captured
    # =====================================================
    set_status(f"Product {index + 1}: OCR Camera 1")
    cam1_ocr = run_label_ocr(cam1_path, "vendor_toa")
    cam1_val = validator.validate_cam1_vendor_toa(cam1_ocr)

    set_status(f"Product {index + 1}: OCR Camera 2")
    cam2_ocr = run_label_ocr(cam2_path, "tob")
    cam2_val = validator.validate_cam2_tob(cam2_ocr)

    result = {
        "product_index": index + 1,
        "cam1_image": cam1_path,
        "cam2_image": cam2_path,
        "cam1_ocr": cam1_ocr,
        "cam1_validation": cam1_val,
        "cam2_ocr": cam2_ocr,
        "cam2_validation": cam2_val
    }

    save_json(f"product_{index+1:03d}.json", result)

    if not cam1_val["ok"] or not cam2_val["ok"]:
        set_status(f"Product {index + 1}: FAIL")
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return False

    set_status(f"Product {index + 1}: PASS")
    sleep(REMOVE_DELAY)
    return True

def process_toc(ctx, validator):
    global current_controller

    set_status(f"Start Camera 3 TOC: total {ctx.toc_rounds} rounds")

    for toc_index in range(ctx.toc_rounds):
        if not running:
            return False

        toc_path = capture_path(f"cam3_toc_{toc_index+1}")

        cam3 = UsbCameraController(
            device_index=USB_DEVICE,
            name=f"Camera 3 TOC {toc_index + 1}/{ctx.toc_rounds}",
            status_cb=set_status,
            preview_cb=update_preview
        )

        current_controller = cam3

        try:
            cam3.open()
            captured = cam3.wait_toc_detect_and_capture(
                filepath=toc_path,
                running_check=lambda: running
            )
        finally:
            cam3.close()
            current_controller = None

        if not captured:
            return False

        set_status(f"TOC {toc_index + 1}: OCR")
        toc_ocr = run_label_ocr(toc_path, "toc")
        toc_val = validator.validate_cam3_toc(toc_ocr, toc_index)

        result = {
            "toc_index": toc_index + 1,
            "toc_image": toc_path,
            "toc_ocr": toc_ocr,
            "toc_validation": toc_val
        }

        save_json(f"toc_{toc_index+1:03d}.json", result)

        if not toc_val["ok"]:
            set_status(f"TOC {toc_index + 1}: FAIL")
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return False

        set_status(f"TOC {toc_index + 1}: PASS")
        sleep(REMOVE_DELAY)

    return True

def sequence_loop(delivery_no, box_ids, quantity):
    global running

    mem = MemoryStore()
    ctx = DeliveryContext(
        delivery_no=delivery_no,
        box_ids=box_ids,
        quantity=quantity
    )
    validator = Validator(ctx, mem)

    job_result = {
        "delivery_no": delivery_no,
        "box_ids": box_ids,
        "quantity": quantity,
        "products": [],
        "toc_rounds": ctx.toc_rounds
    }

    set_status(f"Delivery {delivery_no}: Started")

    for i in range(ctx.quantity):
        if not running:
            break

        progress_label.config(text=f"Product: {i + 1} / {ctx.quantity}")

        ok = process_one_product(i, ctx, validator)

        if not ok:
            running = False
            set_status("Status: FAIL / Sequence stopped")
            save_json("last_job_fail.json", job_result)
            return

    if not running:
        set_status("Status: Stopped")
        return

    box_check = validator.validate_all_box_completed()
    if not box_check["ok"]:
        running = False
        set_status("Box Count FAIL")
        save_json("box_count_fail.json", box_check)
        return

    set_status("All products completed. Start TOC")

    toc_ok = process_toc(ctx, validator)

    if toc_ok:
        set_status("Status: PASS / Job Finished")
        save_json("last_job_pass.json", {
            "delivery_no": delivery_no,
            "quantity": quantity,
            "toa_lots": mem.toa_lots,
            "box_check": box_check
        })
    else:
        set_status("Status: TOC FAIL")

    running = False
    root.after(1500, show_page1)

def start_sequence_thread(delivery_no, box_ids, quantity):
    thread = threading.Thread(
        target=sequence_loop,
        args=(delivery_no, box_ids, quantity),
        daemon=True
    )
    thread.start()

def start_from_input(event=None):
    global running

    delivery_no = delivery_entry.get().strip()
    quantity_text = quantity_entry.get().strip()
    box_ids = parse_box_ids(box_text.get("1.0", tk.END))

    if not delivery_no:
        messagebox.showwarning("Warning", "Please input Delivery No")
        return

    if not quantity_text.isdigit():
        messagebox.showwarning("Warning", "Please input quantity number")
        return

    quantity = int(quantity_text)

    if quantity < 1 or quantity > 100:
        messagebox.showwarning("Warning", "Quantity must be 1 - 100")
        return

    if len(box_ids) != quantity:
        ok = messagebox.askyesno(
            "Confirm",
            f"Box ID count = {len(box_ids)} but Quantity = {quantity}\nContinue?"
        )
        if not ok:
            return

    running = True
    show_page2()
    progress_label.config(text=f"Product: 0 / {quantity}")
    set_status("Status: Sequence Started")
    start_sequence_thread(delivery_no, box_ids, quantity)

def stop_sequence():
    global running, current_controller

    running = False

    try:
        if current_controller is not None:
            current_controller.close()
    except Exception:
        pass

    set_status("Status: Stop Requested")
    root.after(1000, show_page1)

def on_close():
    stop_sequence()
    root.destroy()

def show_page1():
    global running
    running = False

    page2.pack_forget()
    page1.pack(fill="both", expand=True)

    set_status_page1("Input Delivery No, Quantity, Box IDs")

def show_page2():
    page1.pack_forget()
    page2.pack(fill="both", expand=True)

def set_status_page1(text):
    page1_status.config(text=text)

# =========================================================
# GUI
# =========================================================
root = tk.Tk()
root.title("AI-Based Validation System for Shipping Label Verification")
root.geometry("820x620")
root.resizable(False, False)

# PAGE 1
page1 = tk.Frame(root)

title1 = tk.Label(
    page1,
    text="AI-Based Validation System",
    font=("Arial", 20, "bold")
)
title1.pack(pady=20)

tk.Label(page1, text="Delivery No", font=("Arial", 12)).pack()
delivery_entry = tk.Entry(page1, font=("Arial", 16), justify="center", width=24)
delivery_entry.pack(pady=5)

tk.Label(page1, text="Quantity", font=("Arial", 12)).pack()
quantity_entry = tk.Entry(page1, font=("Arial", 16), justify="center", width=10)
quantity_entry.pack(pady=5)

tk.Label(page1, text="Box IDs (comma or new line)", font=("Arial", 12)).pack()
box_text = tk.Text(page1, font=("Arial", 11), width=55, height=8)
box_text.pack(pady=5)

start_btn = tk.Button(
    page1,
    text="START",
    font=("Arial", 14, "bold"),
    width=18,
    command=start_from_input
)
start_btn.pack(pady=12)

page1_status = tk.Label(
    page1,
    text="Input Delivery No, Quantity, Box IDs",
    font=("Arial", 11)
)
page1_status.pack(pady=5)

delivery_entry.bind("<Return>", start_from_input)
quantity_entry.bind("<Return>", start_from_input)

# PAGE 2
page2 = tk.Frame(root)

title2 = tk.Label(
    page2,
    text="AI Camera Validation Running",
    font=("Arial", 16, "bold")
)
title2.pack(pady=5)

preview_frame = tk.Frame(
    page2,
    bg="black",
    width=640,
    height=360
)
preview_frame.pack(pady=5)
preview_frame.pack_propagate(False)

preview_label = tk.Label(preview_frame, bg="black")
preview_label.pack(fill="both", expand=True)

status_label = tk.Label(
    page2,
    text="Status: Idle",
    font=("Arial", 12)
)
status_label.pack(pady=5)

progress_label = tk.Label(
    page2,
    text="Product: 0 / 0",
    font=("Arial", 12, "bold")
)
progress_label.pack(pady=5)

btn_stop = tk.Button(
    page2,
    text="STOP",
    font=("Arial", 14),
    width=18,
    command=stop_sequence
)
btn_stop.pack(pady=10)

root.protocol("WM_DELETE_WINDOW", on_close)

page1.pack(fill="both", expand=True)
delivery_entry.focus()

root.mainloop()
