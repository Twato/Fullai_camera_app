# AI Camera Validation System

ระบบนี้วางโครงไว้ให้รองรับงานจริงตาม Flow:

1. รับ Delivery No + Box ID list + Quantity
2. Camera 1: Pi Camera Autofocus ตรวจสินค้าแบบ Background Change แล้วถ่าย Vendor + TOA
3. Camera 2: Pi Camera Autofocus เปิดแล้วถ่าย TOB ทันที
4. OCR / ROI / Pattern Fix / Validation
5. วน Camera 1 + Camera 2 ตามจำนวนสินค้า
6. Camera 3: USB FullHD Fix Focus ใช้ YOLO detect TOC แล้วถ่ายตามจำนวนกล่อง `ceil(quantity / 6)`
7. OCR TOC แล้วเทียบ LOT NO กับ TOA Memory
8. PASS แล้ววนกลับไปรอ Delivery ใหม่

## ติดตั้งเบื้องต้น

```bash
pip install opencv-python pillow numpy easyocr ultralytics
```

บน Raspberry Pi ที่ใช้ Picamera2:

```bash
sudo apt install -y python3-picamera2
```

## รันระบบ

```bash
python main_app.py
```

## ใส่โมเดล

ใส่ไฟล์โมเดลในโฟลเดอร์ `models/`

ตอนนี้ตั้งค่าไว้ใน `config.py`

- `TOC_DETECT_MODEL_PATH` = ใส่โมเดล TOC ที่มีแล้ว
- `CAM1_ROI_MODEL_PATH` = ยังไม่มี เว้นไว้ก่อน
- `CAM2_ROI_MODEL_PATH` = ยังไม่มี เว้นไว้ก่อน

ถ้ายังไม่มีโมเดล Vendor/TOA/TOB ระบบจะใช้ Manual ROI ชั่วคราวหรือคืนค่า not_ready
