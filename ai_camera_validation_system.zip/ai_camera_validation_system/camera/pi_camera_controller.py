from time import sleep, time
import cv2
import numpy as np

try:
    from picamera2 import Picamera2
except Exception:
    Picamera2 = None

from config import (
    PICAM_PREVIEW_SIZE,
    PICAM_CAPTURE_SIZE,
    MOTION_THRESHOLD,
    STABLE_THRESHOLD,
    STABLE_TIME,
    PICAM_FOCUS_DELAY
)

def gray_from_frame(frame, is_bgr=False):
    if is_bgr:
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    else:
        gray = cv2.cvtColor(frame, cv2.COLOR_RGB2GRAY)
    gray = cv2.GaussianBlur(gray, (21, 21), 0)
    return gray

def motion_score(bg, current):
    diff = cv2.absdiff(bg, current)
    _, thresh = cv2.threshold(diff, 25, 255, cv2.THRESH_BINARY)
    return int(np.sum(thresh))

class PiCameraController:
    def __init__(self, camera_index, name, status_cb=None, preview_cb=None):
        self.camera_index = camera_index
        self.name = name
        self.status_cb = status_cb or print
        self.preview_cb = preview_cb
        self.cam = None

    def status(self, text):
        self.status_cb(f"{self.name}: {text}")

    def open(self):
        if Picamera2 is None:
            raise RuntimeError("Picamera2 not available")

        self.status("Opening")
        self.cam = Picamera2(self.camera_index)

        config = self.cam.create_preview_configuration(
            main={
                "size": PICAM_PREVIEW_SIZE,
                "format": "RGB888"
            }
        )

        self.cam.configure(config)
        self.cam.start()
        sleep(2)

        try:
            self.cam.set_controls({
                "AfMode": 2,
                "AfTrigger": 0
            })
        except Exception as e:
            print("AF setup warning:", e)

    def close(self):
        try:
            if self.cam is not None:
                self.cam.stop()
                self.cam.close()
        except Exception as e:
            print("Close camera error:", e)
        self.cam = None
        self.status("Closed")

    def frame(self):
        return self.cam.capture_array()

    def wait_background_stable(self, running_check=lambda: True):
        stable_start = None
        prev = None

        self.status("Loading Background")

        while running_check():
            frame = self.frame()

            if self.preview_cb:
                self.preview_cb(frame, False)

            gray = gray_from_frame(frame, is_bgr=False)

            if prev is None:
                prev = gray
                sleep(0.2)
                continue

            score = motion_score(prev, gray)
            print(f"{self.name} STABLE SCORE:", score)

            if score < STABLE_THRESHOLD:
                if stable_start is None:
                    stable_start = time()

                if time() - stable_start >= STABLE_TIME:
                    self.status("Background Ready")
                    return gray
            else:
                stable_start = None

            prev = gray
            sleep(0.2)

        return None

    def wait_object_by_background(self, bg, running_check=lambda: True):
        self.status("Waiting Object")

        while running_check():
            frame = self.frame()

            if self.preview_cb:
                self.preview_cb(frame, False)

            gray = gray_from_frame(frame, is_bgr=False)
            score = motion_score(bg, gray)
            print(f"{self.name} MOTION SCORE:", score)

            if score > MOTION_THRESHOLD:
                self.status("Object Detected")
                return True

            sleep(0.2)

        return False

    def autofocus_delay(self, running_check=lambda: True):
        self.status(f"Auto Focus {PICAM_FOCUS_DELAY:.1f} sec")

        try:
            self.cam.set_controls({
                "AfMode": 1,
                "AfTrigger": 0
            })
        except Exception as e:
            print("AF control warning:", e)

        start = time()

        while running_check() and time() - start < PICAM_FOCUS_DELAY:
            frame = self.frame()
            if self.preview_cb:
                self.preview_cb(frame, False)
            sleep(0.2)

        try:
            self.cam.set_controls({
                "AfMode": 2,
                "AfTrigger": 0
            })
        except Exception as e:
            print("AF continuous warning:", e)

    def capture_file(self, filepath):
        self.status("Capturing Full Image")

        still_config = self.cam.create_still_configuration(
            main={"size": PICAM_CAPTURE_SIZE}
        )

        self.cam.switch_mode_and_capture_file(still_config, filepath)
        self.status(f"Saved {filepath}")
        return filepath
