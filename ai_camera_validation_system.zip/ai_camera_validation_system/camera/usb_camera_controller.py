from time import sleep, time
import cv2

from config import (
    USB_CAPTURE_WIDTH,
    USB_CAPTURE_HEIGHT,
    USB_CAPTURE_FPS,
    USB_STABLE_CAPTURE_DELAY,
    YOLO_CONF_THRES,
    YOLO_IMAGE_SIZE,
    TOC_DETECT_MODEL_PATH
)

from detection.yolo_detector import YoloDetector

class UsbCameraController:
    def __init__(self, device_index, name, status_cb=None, preview_cb=None):
        self.device_index = device_index
        self.name = name
        self.status_cb = status_cb or print
        self.preview_cb = preview_cb
        self.cap = None
        self.detector = YoloDetector(
            model_path=TOC_DETECT_MODEL_PATH,
            conf=YOLO_CONF_THRES,
            imgsz=YOLO_IMAGE_SIZE
        )

    def status(self, text):
        self.status_cb(f"{self.name}: {text}")

    def open(self):
        self.status(f"Opening /dev/video{self.device_index}")

        self.cap = cv2.VideoCapture(f"/dev/video{self.device_index}", cv2.CAP_V4L2)

        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, USB_CAPTURE_WIDTH)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, USB_CAPTURE_HEIGHT)
        self.cap.set(cv2.CAP_PROP_FPS, USB_CAPTURE_FPS)
        self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

        if not self.cap.isOpened():
            raise RuntimeError(f"Cannot open USB camera /dev/video{self.device_index}")

        self.warmup()

    def warmup(self):
        self.status("USB Warm Up")
        start = time()

        while time() - start < 1.5:
            ret, frame = self.cap.read()
            if ret and self.preview_cb:
                self.preview_cb(frame, True)
            sleep(0.1)

    def close(self):
        try:
            if self.cap is not None:
                self.cap.release()
        except Exception:
            pass
        self.cap = None
        self.status("Closed")

    def wait_toc_detect_and_capture(self, filepath, running_check=lambda: True):
        """
        ใช้ YOLO detect TOC ก่อน แล้วต้อง detect ต่อเนื่องตาม delay ถึงถ่าย
        """
        if not self.detector.ready:
            self.status("TOC model not ready, capture first readable frame")
            while running_check():
                ret, frame = self.cap.read()
                if ret:
                    cv2.imwrite(filepath, frame, [cv2.IMWRITE_JPEG_QUALITY, 100])
                    return filepath
                sleep(0.2)
            return None

        first_detect_time = None
        last_frame = None

        self.status("Waiting TOC Label")

        while running_check():
            ret, frame = self.cap.read()

            if not ret:
                self.status("Cannot Read Frame")
                sleep(0.2)
                continue

            last_frame = frame.copy()

            if self.preview_cb:
                self.preview_cb(frame, True)

            detections = self.detector.detect(frame)
            detected = len(detections) > 0

            now = time()

            if detected:
                if first_detect_time is None:
                    first_detect_time = now

                hold = now - first_detect_time
                self.status(f"TOC Detected {hold:.1f}/{USB_STABLE_CAPTURE_DELAY:.1f} sec")

                if hold >= USB_STABLE_CAPTURE_DELAY:
                    cv2.imwrite(filepath, last_frame, [cv2.IMWRITE_JPEG_QUALITY, 100])
                    self.status(f"Saved {filepath}")
                    return filepath

            else:
                first_detect_time = None
                self.status("Waiting TOC Label")

            sleep(0.05)

        return None
