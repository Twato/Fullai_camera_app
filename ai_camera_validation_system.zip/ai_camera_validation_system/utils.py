import os
from datetime import datetime

def ensure_dirs(*dirs):
    for d in dirs:
        os.makedirs(d, exist_ok=True)

def timestamp_name(prefix, ext="jpg"):
    return datetime.now().strftime(f"{prefix}_%Y%m%d_%H%M%S.%f.{ext}")

def safe_float(value, default=0.0):
    try:
        return float(value)
    except Exception:
        return default
