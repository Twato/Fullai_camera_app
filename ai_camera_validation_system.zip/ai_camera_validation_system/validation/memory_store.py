class MemoryStore:
    def __init__(self):
        self.reset()

    def reset(self):
        self.vendor_box_ids = set()
        self.toa_lots = []
        self.toa_lot_set = set()
        self.tob_lot_set = set()
        self.toc_lot_set = set()
        self.date_codes = {
            "vendor": [],
            "toa": [],
            "tob": []
        }

    def add_vendor_box_id(self, box_id):
        self.vendor_box_ids.add(box_id)

    def add_toa_lot(self, lot):
        if lot in self.toa_lot_set:
            return False
        self.toa_lots.append(lot)
        self.toa_lot_set.add(lot)
        return True

    def add_tob_lot(self, lot):
        if lot in self.tob_lot_set:
            return False
        self.tob_lot_set.add(lot)
        return True

    def add_toc_lot(self, lot):
        if lot in self.toc_lot_set:
            return False
        self.toc_lot_set.add(lot)
        return True

    def add_date_code(self, group, date_code):
        if group in self.date_codes:
            self.date_codes[group].append(date_code)

    def all_date_codes(self):
        out = []
        for values in self.date_codes.values():
            out.extend(values)
        return out
