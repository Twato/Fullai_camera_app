class Validator:
    def __init__(self, delivery_context, memory_store):
        self.ctx = delivery_context
        self.mem = memory_store

    def validate_cam1_vendor_toa(self, ocr_result):
        errors = []
        fields = ocr_result.get("fields", {})

        vendor_box_id = fields.get("vendor_box_id", {}).get("fixed", "")
        vendor_date = fields.get("vendor_date_code", {}).get("fixed", "")
        toa_lot = fields.get("toa_lot", {}).get("fixed", "")
        toa_date = fields.get("toa_date_code", {}).get("fixed", "")

        if not vendor_box_id:
            errors.append("Vendor Box ID OCR empty")
        elif vendor_box_id not in self.ctx.box_ids:
            errors.append(f"Box ID not in Delivery: {vendor_box_id}")
        else:
            self.mem.add_vendor_box_id(vendor_box_id)

        if not toa_lot:
            errors.append("TOA LOT OCR empty")
        else:
            if not self.mem.add_toa_lot(toa_lot):
                errors.append(f"Duplicate TOA LOT: {toa_lot}")

        if vendor_date:
            self.mem.add_date_code("vendor", vendor_date)
        else:
            errors.append("Vendor Date Code empty")

        if toa_date:
            self.mem.add_date_code("toa", toa_date)
        else:
            errors.append("TOA Date Code empty")

        if vendor_date and toa_date and vendor_date != toa_date:
            errors.append(f"Vendor Date != TOA Date: {vendor_date} != {toa_date}")

        return {
            "ok": len(errors) == 0,
            "errors": errors,
            "data": {
                "vendor_box_id": vendor_box_id,
                "vendor_date_code": vendor_date,
                "toa_lot": toa_lot,
                "toa_date_code": toa_date
            }
        }

    def validate_cam2_tob(self, ocr_result):
        errors = []
        fields = ocr_result.get("fields", {})

        tob_lot = fields.get("tob_lot", {}).get("fixed", "")
        tob_date = fields.get("tob_date_code", {}).get("fixed", "")

        if not tob_lot:
            errors.append("TOB LOT OCR empty")
        else:
            if not self.mem.add_tob_lot(tob_lot):
                errors.append(f"Duplicate TOB LOT: {tob_lot}")

        if tob_date:
            self.mem.add_date_code("tob", tob_date)
        else:
            errors.append("TOB Date Code empty")

        # เทียบ date กับค่าก่อนหน้าแบบง่าย
        all_dates = self.mem.all_date_codes()
        if len(all_dates) >= 2:
            first = all_dates[0]
            for d in all_dates:
                if d != first:
                    errors.append(f"Date Code mismatch: {all_dates}")
                    break

        return {
            "ok": len(errors) == 0,
            "errors": errors,
            "data": {
                "tob_lot": tob_lot,
                "tob_date_code": tob_date
            }
        }

    def validate_all_box_completed(self):
        missing = sorted(list(self.ctx.box_ids - self.mem.vendor_box_ids))
        ok = len(missing) == 0 and len(self.mem.vendor_box_ids) == self.ctx.quantity

        return {
            "ok": ok,
            "missing_box_ids": missing,
            "scanned_count": len(self.mem.vendor_box_ids),
            "expected_quantity": self.ctx.quantity
        }

    def validate_cam3_toc(self, ocr_result, toc_index):
        errors = []
        fields = ocr_result.get("fields", {})

        toc_delivery = fields.get("toc_delivery_no", {}).get("fixed", "")
        toc_lot = fields.get("toc_lot", {}).get("fixed", "")

        if toc_delivery and toc_delivery != self.ctx.delivery_no:
            errors.append(f"TOC Delivery mismatch: {toc_delivery} != {self.ctx.delivery_no}")

        if not toc_delivery:
            errors.append("TOC Delivery No empty")

        # ตอนนี้ OCR Module คืน toc_lot ได้ 1 ค่า
        # ถ้า TOC 1 ใบมีหลาย LOT ต้องปรับ detector/OCR ให้แยกหลาย ROI หรืออ่านหลายบรรทัดภายหลัง
        toc_lots = []
        if toc_lot:
            toc_lots.append(toc_lot)

        if not toc_lots:
            errors.append("TOC LOT empty")

        for lot in toc_lots:
            if lot not in self.mem.toa_lot_set:
                errors.append(f"TOC LOT not found in TOA memory: {lot}")

            if not self.mem.add_toc_lot(lot):
                errors.append(f"Duplicate TOC LOT: {lot}")

        expected_count = self.ctx.expected_toc_lot_count(toc_index)

        return {
            "ok": len(errors) == 0,
            "errors": errors,
            "data": {
                "toc_delivery_no": toc_delivery,
                "toc_lots": toc_lots,
                "expected_lot_count_in_this_toc": expected_count
            }
        }
