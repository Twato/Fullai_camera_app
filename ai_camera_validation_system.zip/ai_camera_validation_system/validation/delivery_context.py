from math import ceil
from config import TOC_CAPACITY

class DeliveryContext:
    def __init__(self, delivery_no, box_ids, quantity):
        self.delivery_no = delivery_no
        self.box_ids = set(box_ids)
        self.quantity = int(quantity)

    @property
    def toc_rounds(self):
        return ceil(self.quantity / TOC_CAPACITY)

    def expected_toc_lot_count(self, toc_index):
        """
        toc_index เริ่มจาก 0
        เช่น quantity=10, capacity=6
        toc_index 0 = 6
        toc_index 1 = 4
        """
        remaining = self.quantity - (toc_index * TOC_CAPACITY)
        if remaining >= TOC_CAPACITY:
            return TOC_CAPACITY
        return max(0, remaining)
