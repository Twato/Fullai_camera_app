import os
from ultralytics import YOLO

class YoloDetector:
    def __init__(self, model_path=None, conf=0.40, imgsz=640):
        self.model_path = model_path
        self.conf = conf
        self.imgsz = imgsz
        self.model = None

    @property
    def ready(self):
        return self.model_path is not None and os.path.exists(self.model_path)

    def load(self):
        if not self.ready:
            return False
        if self.model is None:
            self.model = YOLO(self.model_path)
        return True

    def detect(self, image):
        if not self.load():
            return []

        results = self.model(
            image,
            conf=self.conf,
            imgsz=self.imgsz,
            verbose=False
        )

        detections = []

        for r in results:
            for box in r.boxes:
                x1, y1, x2, y2 = map(int, box.xyxy[0])
                conf = float(box.conf[0])
                cls = int(box.cls[0])
                name = self.model.names[cls]

                detections.append({
                    "name": name,
                    "conf": conf,
                    "box": [x1, y1, x2, y2]
                })

        return detections

    def detect_best_by_class(self, image):
        detections = self.detect(image)
        best = {}

        for det in detections:
            name = det["name"]
            if name not in best or det["conf"] > best[name]["conf"]:
                best[name] = det

        return list(best.values())
