class HalconDetector:
    """
    Placeholder สำหรับ HALCON
    ตอนนี้เว้นไว้ก่อน เพราะโมเดล/โค้ด HALCON ยังไม่สมบูรณ์

    ภายหลังให้ทำ interface ให้ return format เดียวกับ YOLO:
    [
        {"name": "toc", "conf": 0.95, "box": [x1, y1, x2, y2]}
    ]
    """
    def __init__(self, model_path=None):
        self.model_path = model_path

    def detect(self, image):
        return []
