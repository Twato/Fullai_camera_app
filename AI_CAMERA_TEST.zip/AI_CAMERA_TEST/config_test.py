import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

OUTPUT_DIR = os.path.join(BASE_DIR, "output")
CAPTURE_DIR = os.path.join(OUTPUT_DIR, "captures")
ROI_DIR = os.path.join(OUTPUT_DIR, "roi")
OCR_DIR = os.path.join(OUTPUT_DIR, "ocr")

# =====================
# CAMERA
# =====================
PICAM1_INDEX = 0
PICAM2_INDEX = 1
USB_DEVICE = 0

PICAM_PREVIEW_SIZE = (640, 480)
PICAM_CAPTURE_SIZE = (1280, 720)

USB_WIDTH = 1280
USB_HEIGHT = 720
USB_FPS = 15

PREVIEW_SIZE = (640, 360)
PREVIEW_INTERVAL = 0.3

# =====================
# PI CAMERA DETECT
# =====================
MOTION_THRESHOLD = 50000
STABLE_THRESHOLD = 70000
STABLE_TIME = 1.0
FOCUS_DELAY = 2.0

# =====================
# ROI TEST
# =====================
# crop กลางภาพขนาด 100x50 ตามที่ขอ
CENTER_ROI_W = 100
CENTER_ROI_H = 50

# ขยายก่อน OCR
OCR_SCALE = 4

# =====================
# OCR
# =====================
ALLOWLIST = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-_."

# =====================
# TOC YOLO MODEL
# ถ้ายังไม่มีไฟล์นี้ ระบบจะถ่าย USB ทันที ไม่ detect
# =====================
TOC_MODEL_PATH = os.path.join(BASE_DIR, "models", "toc_best.pt")
YOLO_CONF = 0.40
YOLO_IMGSZ = 640
USB_HOLD_TIME = 2.0
