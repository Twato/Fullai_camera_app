# AI_CAMERA_TEST

โปรเจคนี้เป็นตัวทดสอบแยกจากตัวหลัก

ใช้สำหรับ:
- รับ Delivery No + Quantity
- เปิด Camera 1 ถ่ายภาพ
- Crop กลางภาพ 100x50
- OCR ด้วย EasyOCR
- แสดงค่าที่อ่านได้บน UI
- เปิด Camera 2 ถ่ายภาพ
- Crop กลางภาพ 100x50
- OCR
- แสดงค่าที่อ่านได้
- ครบจำนวนแล้วกด Continue to TOC
- เปิด USB Camera / Camera 3
- ถ้ามี YOLO model จะ detect ก่อนถ่าย
- ถ้าไม่มี model จะถ่ายภาพทันที
- Crop กลางภาพ 100x50
- OCR
- แสดงค่าที่อ่านได้

## ติดตั้ง

```bash
pip install opencv-python pillow numpy easyocr ultralytics
```

บน Raspberry Pi:

```bash
sudo apt install -y python3-picamera2
```

## รัน

```bash
python main_test_ui.py
```

## แก้ค่าหลัก

แก้ในไฟล์:

```bash
config_test.py
```

เช่น camera index, crop size, path model
