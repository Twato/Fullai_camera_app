from picamera2 import Picamera2
from time import sleep, time
from datetime import datetime
from PIL import Image, ImageTk
from ultralytics import YOLO

import os
import threading
from threading import Event
import cv2
import numpy as np
import tkinter as tk
from tkinter import messagebox
import easyocr
import re


# =========================================================
# CONFIG
# =========================================================
SAVE_DIR = "captures"
MODEL_PATH = "/home/toto/rpicam_apps_1.9.0-2_arm64/models/best.pt"

PICAM0_INDEX = 0
PICAM1_INDEX = 1
USB_DEVICE = 0

PICAM_PREVIEW_SIZE = (640, 480)
PICAM_CAPTURE_SIZE = (1280, 720)

USB_CAPTURE_WIDTH = 1280
USB_CAPTURE_HEIGHT = 720
USB_CAPTURE_FPS = 15
USB_PREVIEW_SIZE = (480, 270)

PREVIEW_INTERVAL = 0.5
DETECT_INTERVAL = 0.5
YOLO_IMAGE_SIZE = 416
CONF_THRES = 0.75

USB_STABLE_CAPTURE_DELAY = 3.0
PICAM_FOCUS_DELAY = 5.0
REMOVE_DELAY = 5.0

MOTION_THRESHOLD = 50000
STABLE_THRESHOLD = 70000
STABLE_TIME = 1.5

SHOW_DETECTION_BOX = True

# =========================================================
# OCR CONFIG
# =========================================================
ENABLE_OCR = True

# ROI ๏ฟฝ๏ฟฝาง๏ฟฝาพ๏ฟฝัต๏ฟฝ๏ฟฝัต๏ฟฝ
# 0.50 x 0.50 = ๏ฟฝ๏ฟฝ้นท๏ฟฝ๏ฟฝ 1/4 ๏ฟฝอง๏ฟฝาพ
AUTO_CENTER_ROI = True
ROI_W_RATIO = 0.50
ROI_H_RATIO = 0.50

# ๏ฟฝ๏ฟฝ๏ฟฝ๏ฟฝ๏ฟฝาก fix ROI ๏ฟฝอง๏ฟฝ๏ฟฝ๏ฟฝ๏ฟฝ๏ฟฝัง ๏ฟฝ๏ฟฝ๏ฟฝ๏ฟฝ๏ฟฝ๏ฟฝ๏ฟฝยน AUTO_CENTER_ROI = False
# ๏ฟฝ๏ฟฝ๏ฟฝ๏ฟฝ๏ฟฝ๏ฟฝ๏ฟฝ๏ฟฝ๏ฟฝแบบ (x, y, w, h)
OCR_ROI = {
    "cam0_bag": None,
    "cam1_box": None,
    "usb_carton": None,
}

OCR_PI_ALLOWLIST = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-_."
OCR_USB_ALLOWLIST = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-_."

# ลด๏ฟฝาก x5 ๏ฟฝ๏ฟฝ๏ฟฝ๏ฟฝ๏ฟฝ x2 ๏ฟฝัน RAM ๏ฟฝ๏ฟฝ๏ฟฝ
OCR_SCALE_PI = 2
OCR_SCALE_USB = 2

os.makedirs(SAVE_DIR, exist_ok=True)


# =========================================================
# GLOBAL
# =========================================================
running = False
current_camera = None

result_ok_event = Event()
target_count = 0
current_count = 0
last_preview_time = 0

model = None
ocr_reader = None


# =========================================================
# BASIC UI / UTIL
# =========================================================
def set_status(text):
    try:
        status_label.config(text=text)
        root.update_idletasks()
    except Exception:
        pass
    print(text)


def make_folder(name):
    folder = os.path.join(SAVE_DIR, name)
    os.makedirs(folder, exist_ok=True)
    return folder


def filename(camera_name):
    folder = make_folder(camera_name)
    name = datetime.now().strftime(f"{camera_name}_%Y%m%d_%H%M%S.jpg")
    return os.path.join(folder, name)


def update_preview(frame, is_bgr=False):
    global last_preview_time

    now = time()
    if now - last_preview_time < PREVIEW_INTERVAL:
        return

    last_preview_time = now

    try:
        display = cv2.resize(frame, USB_PREVIEW_SIZE)

        if is_bgr:
            display = cv2.cvtColor(display, cv2.COLOR_BGR2RGB)

        img = Image.fromarray(display)
        imgtk = ImageTk.PhotoImage(image=img)

        preview_label.imgtk = imgtk
        preview_label.config(image=imgtk)

    except Exception as e:
        print("Preview Error:", e)


# =========================================================
# OCR SYSTEM
# =========================================================
def load_ocr_once():
    global ocr_reader

    if not ENABLE_OCR:
        return

    if ocr_reader is None:
        set_status("Loading OCR Model...")
        ocr_reader = easyocr.Reader(["en"], gpu=False)
        set_status("OCR Model Ready")


def get_center_roi(image):
    h, w = image.shape[:2]

    roi_w = int(w * ROI_W_RATIO)
    roi_h = int(h * ROI_H_RATIO)

    x = int((w - roi_w) / 2)
    y = int((h - roi_h) / 2)

    return x, y, roi_w, roi_h


def crop_by_roi(image, camera_name):
    if AUTO_CENTER_ROI:
        x, y, w, h = get_center_roi(image)
        print(f"{camera_name} AUTO ROI: x={x}, y={y}, w={w}, h={h}")
        return image[y:y + h, x:x + w]

    roi = OCR_ROI.get(camera_name)

    if roi is None:
        return image

    x, y, w, h = roi
    print(f"{camera_name} FIX ROI: x={x}, y={y}, w={w}, h={h}")
    return image[y:y + h, x:x + w]


def preprocess_ocr_pi(crop):
    gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)

    gray = cv2.resize(
        gray,
        None,
        fx=OCR_SCALE_PI,
        fy=OCR_SCALE_PI,
        interpolation=cv2.INTER_CUBIC
    )

    gray = cv2.convertScaleAbs(
        gray,
        alpha=1.25,
        beta=5
    )

    sharpen_kernel = np.array([
        [0, -0.5, 0],
        [-0.5, 3, -0.5],
        [0, -0.5, 0]
    ], dtype=np.float32)

    gray = cv2.filter2D(gray, -1, sharpen_kernel)

    return gray


def preprocess_ocr_usb(crop):
    gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)

    gray = cv2.resize(
        gray,
        None,
        fx=OCR_SCALE_USB,
        fy=OCR_SCALE_USB,
        interpolation=cv2.INTER_CUBIC
    )

    gray = cv2.convertScaleAbs(
        gray,
        alpha=1.25,
        beta=5
    )

    sharpen_kernel = np.array([
        [0, -0.5, 0],
        [-0.5, 3, -0.5],
        [0, -0.5, 0]
    ], dtype=np.float32)

    gray = cv2.filter2D(gray, -1, sharpen_kernel)

    return gray


def clean_ocr_text(text):
    text = text.strip()
    text = text.replace(" ", "")
    text = text.replace("\n", "")
    text = text.replace("\t", "")
    text = re.sub(r"[^A-Za-z0-9\-_.]", "", text)
    return text


def run_ocr_image(image_path, camera_name, ocr_type):
    if not ENABLE_OCR:
        return ""

    if ocr_reader is None:
        load_ocr_once()

    if not os.path.exists(image_path):
        print("OCR Image not found:", image_path)
        return ""

    image = cv2.imread(image_path)

    if image is None:
        print("OCR Cannot load image:", image_path)
        return ""

    crop = crop_by_roi(image, camera_name)

    if ocr_type == "pi":
        gray = preprocess_ocr_pi(crop)
        allowlist = OCR_PI_ALLOWLIST
    else:
        gray = preprocess_ocr_usb(crop)
        allowlist = OCR_USB_ALLOWLIST

    print("OCR SHAPE:", gray.shape)

    roi_save_path = image_path.replace(".jpg", "_ocr_roi.jpg")
    cv2.imwrite(roi_save_path, gray)

    results = ocr_reader.readtext(
        gray,
        allowlist=allowlist,
        detail=1,
        paragraph=False,
        decoder="beamsearch"
    )

    raw_final = ""

    print("\n===== OCR RESULT =====")
    print("CAMERA :", camera_name)
    print("IMAGE  :", image_path)

    if not results:
        print("No text detected")
        print("ROI IMAGE:", roi_save_path)
        print("======================\n")
        set_status(f"{camera_name}: OCR No Text")
        return ""

    for bbox, text, conf in results:
        print(f"TEXT: {text}")
        print(f"CONF: {conf:.2f}")
        print("-------------------")
        raw_final += text

    clean_final = clean_ocr_text(raw_final)

    print("RAW FINAL   :", raw_final)
    print("CLEAN FINAL :", clean_final)
    print("ROI IMAGE   :", roi_save_path)
    print("======================\n")

    set_status(f"{camera_name}: OCR = {clean_final}")

    return clean_final

# =========================================================
# MOTION / STABLE FOR PI CAMERA
# =========================================================
def gray_from_frame(frame, is_bgr=False):
    if is_bgr:
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    else:
        gray = cv2.cvtColor(frame, cv2.COLOR_RGB2GRAY)

    gray = cv2.GaussianBlur(gray, (21, 21), 0)
    return gray


def motion_score(bg, current):
    diff = cv2.absdiff(bg, current)
    _, thresh = cv2.threshold(diff, 25, 255, cv2.THRESH_BINARY)
    return int(np.sum(thresh))


def wait_stable_picam(cam):
    stable_start = None
    prev = None

    while running:
        frame = cam.capture_array()
        update_preview(frame, is_bgr=False)

        gray = gray_from_frame(frame, is_bgr=False)

        if prev is None:
            prev = gray
            sleep(0.2)
            continue

        score = motion_score(prev, gray)
        print("PICAM STABLE SCORE:", score)

        if score < STABLE_THRESHOLD:
            if stable_start is None:
                stable_start = time()

            if time() - stable_start >= STABLE_TIME:
                return gray
        else:
            stable_start = None

        prev = gray
        sleep(0.2)

    return None


def focus_with_preview_picam(cam, camera_name):
    set_status(f"{camera_name}: Auto Focus {PICAM_FOCUS_DELAY:.1f} sec")

    try:
        cam.set_controls({
            "AfMode": 1,
            "AfTrigger": 0
        })
    except Exception as e:
        print("AF control warning:", e)

    start_time = time()

    while running and time() - start_time < PICAM_FOCUS_DELAY:
        frame = cam.capture_array()
        update_preview(frame, is_bgr=False)
        sleep(0.2)

    try:
        cam.set_controls({
            "AfMode": 2,
            "AfTrigger": 0
        })
    except Exception as e:
        print("AF continuous warning:", e)

def run_picamera(camera_index, camera_name):
    global current_camera

    cam = None

    try:
        set_status(f"{camera_name}: Opening Camera")

        cam = Picamera2(camera_index)
        current_camera = cam

        config = cam.create_preview_configuration(
            main={
                "size": PICAM_PREVIEW_SIZE,
                "format": "RGB888"
            }
        )

        cam.configure(config)
        cam.start()
        sleep(3)

        try:
            cam.set_controls({
                "AfMode": 2,
                "AfTrigger": 0
            })
        except Exception as e:
            print("AF setup warning:", e)

        set_status(f"{camera_name}: Loading Background")
        bg = wait_stable_picam(cam)

        if bg is None:
            return

        set_status(f"{camera_name}: Ready / Waiting Object")

        while running:
            frame = cam.capture_array()
            update_preview(frame, is_bgr=False)

            gray = gray_from_frame(frame, is_bgr=False)
            score = motion_score(bg, gray)
            print(f"{camera_name} MOTION SCORE:", score)

            if score > MOTION_THRESHOLD:
                set_status(f"{camera_name}: Object Detected")
                sleep(0.5)

                focus_with_preview_picam(cam, camera_name)

                filepath = filename(camera_name)
                set_status(f"{camera_name}: Capturing Full Image")

                still_config = cam.create_still_configuration(
                    main={"size": PICAM_CAPTURE_SIZE}
                )

                cam.switch_mode_and_capture_file(still_config, filepath)

                print("Saved:", filepath)
                set_status(f"{camera_name}: Saved Image")

                run_ocr_image(filepath, camera_name, "pi")

                sleep(REMOVE_DELAY)
                break

            sleep(0.3)

    except Exception as e:
        print(f"{camera_name} Error:", e)
        set_status(f"{camera_name}: Error {e}")

    finally:
        try:
            if cam is not None:
                cam.stop()
                cam.close()
        except Exception as e:
            print("Close camera error:", e)

        current_camera = None
        set_status(f"{camera_name}: Closed")
        sleep(1)


def run_picamera_direct_capture(camera_index, camera_name):
    global current_camera

    cam = None

    try:
        set_status(f"{camera_name}: Opening Camera")

        cam = Picamera2(camera_index)
        current_camera = cam

        config = cam.create_preview_configuration(
            main={
                "size": PICAM_PREVIEW_SIZE,
                "format": "RGB888"
            }
        )

        cam.configure(config)
        cam.start()
        sleep(2)

        try:
            cam.set_controls({
                "AfMode": 2,
                "AfTrigger": 0
            })
        except Exception as e:
            print("AF setup warning:", e)

        focus_with_preview_picam(cam, camera_name)

        filepath = filename(camera_name)
        set_status(f"{camera_name}: Capturing Full Image")

        still_config = cam.create_still_configuration(
            main={"size": PICAM_CAPTURE_SIZE}
        )

        cam.switch_mode_and_capture_file(still_config, filepath)

        print("Saved:", filepath)
        set_status(f"{camera_name}: Saved Image")

        run_ocr_image(filepath, camera_name, "pi")

        sleep(REMOVE_DELAY)

    except Exception as e:
        print(f"{camera_name} Error:", e)
        set_status(f"{camera_name}: Error {e}")

    finally:
        try:
            if cam is not None:
                cam.stop()
                cam.close()
        except Exception as e:
            print("Close camera error:", e)

        current_camera = None
        set_status(f"{camera_name}: Closed")
        sleep(1)


# =========================================================
# YOLO USB CAMERA
# =========================================================
def load_model_once():
    global model

    if model is None:
        set_status("Loading YOLO Model...")
        model = YOLO(MODEL_PATH)
        set_status("YOLO Model Ready")


def open_usb_camera(device_index, camera_name):
    cap = cv2.VideoCapture(f"/dev/video{device_index}", cv2.CAP_V4L2)

    cap.set(cv2.CAP_PROP_FRAME_WIDTH, USB_CAPTURE_WIDTH)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, USB_CAPTURE_HEIGHT)
    cap.set(cv2.CAP_PROP_FPS, USB_CAPTURE_FPS)
    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

    if not cap.isOpened():
        set_status(f"{camera_name}: Cannot Open USB Camera /dev/video{device_index}")
        return None

    return cap


def detect_label_yolo(frame):
    detected = False
    display_frame = frame.copy()

    results = model(
        frame,
        conf=CONF_THRES,
        imgsz=YOLO_IMAGE_SIZE,
        verbose=False
    )

    if SHOW_DETECTION_BOX:
        for r in results:
            for box in r.boxes:
                detected = True

                x1, y1, x2, y2 = map(int, box.xyxy[0])
                conf = float(box.conf[0])
                cls = int(box.cls[0])
                name = model.names[cls]

                cv2.rectangle(display_frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                cv2.putText(
                    display_frame,
                    f"{name} {conf:.2f}",
                    (x1, max(y1 - 10, 20)),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.7,
                    (0, 255, 0),
                    2
                )
    else:
        for r in results:
            if len(r.boxes) > 0:
                detected = True
                break

    return detected, display_frame

def warmup_usb(cap, camera_name):
    set_status(f"{camera_name}: USB Warm Up")
    start = time()

    while running and time() - start < 1.5:
        ret, frame = cap.read()
        if ret:
            update_preview(frame, is_bgr=True)
        sleep(0.1)


def run_usb_camera_ai(device_index, camera_name):
    cap = None
    last_detect_run = 0
    first_detect_time = None
    last_full_frame = None
    last_display_frame = None

    try:
        load_model_once()

        set_status(f"{camera_name}: Opening USB Camera")
        cap = open_usb_camera(device_index, camera_name)

        if cap is None:
            return

        warmup_usb(cap, camera_name)

        set_status(f"{camera_name}: Ready / Waiting Label")

        while running:
            ret, frame = cap.read()

            if not ret:
                set_status(f"{camera_name}: Cannot Read Frame")
                sleep(0.2)
                continue

            last_full_frame = frame.copy()
            now = time()

            if last_display_frame is not None:
                update_preview(last_display_frame, is_bgr=True)
            else:
                update_preview(frame, is_bgr=True)

            if now - last_detect_run >= DETECT_INTERVAL:
                last_detect_run = now

                detected, display_frame = detect_label_yolo(frame)
                last_display_frame = display_frame

                if detected:
                    if first_detect_time is None:
                        first_detect_time = now
                        set_status(f"{camera_name}: Label Detected / Hold Still")

                    hold_time = now - first_detect_time
                    set_status(
                        f"{camera_name}: Label Detected "
                        f"{hold_time:.1f}/{USB_STABLE_CAPTURE_DELAY:.1f} sec"
                    )

                    if hold_time >= USB_STABLE_CAPTURE_DELAY:
                        filepath = filename(camera_name)

                        cv2.imwrite(
                            filepath,
                            last_full_frame,
                            [cv2.IMWRITE_JPEG_QUALITY, 100]
                        )

                        print("Saved:", filepath)
                        set_status(f"{camera_name}: Saved Full Image")

                        run_ocr_image(filepath, camera_name, "usb")

                        sleep(REMOVE_DELAY)
                        break

                else:
                    first_detect_time = None
                    set_status(f"{camera_name}: Ready / Waiting Label")

            sleep(0.03)

    except Exception as e:
        print(f"{camera_name} Error:", e)
        set_status(f"{camera_name}: Error {e}")

    finally:
        if cap is not None:
            cap.release()

        set_status(f"{camera_name}: Closed")
        sleep(1)


# =========================================================
# SEQUENCE
# =========================================================
def sequence_loop():
    global running, current_count

    while running and current_count < target_count:
        run_picamera(PICAM0_INDEX, "cam0_bag")

        if not running:
            break

        run_picamera_direct_capture(PICAM1_INDEX, "cam1_box")

        if not running:
            break

        run_usb_camera_ai(USB_DEVICE, "usb_carton")

        if not running:
            break

        current_count += 1

        progress_label.config(
            text=f"Progress: {current_count} / {target_count}"
        )

        if current_count >= target_count:
            running = False
            set_status("Status: Finish Job")
            root.after(1500, show_page1)
            break

    set_status("Status: Sequence Stopped")

def start_sequence_thread():
    thread = threading.Thread(target=sequence_loop, daemon=True)
    thread.start()


def stop_sequence():
    global running, current_camera

    running = False

    try:
        if current_camera is not None:
            current_camera.stop()
            current_camera.close()
    except Exception:
        pass

    set_status("Status: Stop Requested")
    root.after(1000, show_page1)


def on_close():
    stop_sequence()
    root.destroy()


# =========================================================
# PAGE CONTROL
# =========================================================
def show_page1():
    global running

    running = False

    page2.pack_forget()
    page1.pack(fill="both", expand=True)

    count_entry.delete(0, tk.END)
    count_entry.focus()

    set_page1_status("Please input quantity 1 - 100")


def show_page2():
    page1.pack_forget()
    page2.pack(fill="both", expand=True)


def set_page1_status(text):
    page1_status.config(text=text)


def preload_models_before_start():
    """
    ๏ฟฝ๏ฟฝลด OCR ๏ฟฝ๏ฟฝ๏ฟฝ๏ฟฝ๏ฟฝ๏ฟฝ๏ฟฝ๏ฟฝ๏ฟฝ๏ฟฝ๏ฟฝ๏ฟฝ๏ฟฝ๏ฟฝ๏ฟฝาน
    """
    load_ocr_once()


def start_from_input(event=None):
    global target_count, current_count, running

    value = count_entry.get().strip()

    if not value.isdigit():
        messagebox.showwarning("Warning", "Please input number only")
        return

    count = int(value)

    if count < 1 or count > 100:
        messagebox.showwarning("Warning", "Please input number 1 - 100")
        return

    target_count = count
    current_count = 0
    running = True

    show_page2()

    progress_label.config(text=f"Progress: 0 / {target_count}")
    set_status("Status: Loading OCR Before Start")

    preload_models_before_start()

    set_status("Status: Sequence Started")
    start_sequence_thread()


# =========================================================
# GUI
# =========================================================
root = tk.Tk()
root.title("AI Camera 3-Camera Data Collection + OCR")
root.geometry("760x520")
root.resizable(False, False)

# PAGE 1
page1 = tk.Frame(root)

title1 = tk.Label(
    page1,
    text="AI Camera Data Collection",
    font=("Arial", 20, "bold")
)
title1.pack(pady=40)

sub1 = tk.Label(
    page1,
    text="Input Quantity",
    font=("Arial", 16)
)
sub1.pack(pady=10)

count_entry = tk.Entry(
    page1,
    font=("Arial", 28),
    justify="center",
    width=8
)
count_entry.pack(pady=10)

hint1 = tk.Label(
    page1,
    text="Input number 1 - 100 and press Enter",
    font=("Arial", 12),
    fg="gray"
)
hint1.pack(pady=10)

page1_status = tk.Label(
    page1,
    text="Please input quantity 1 - 100",
    font=("Arial", 12)
)
page1_status.pack(pady=10)

count_entry.bind("<Return>", start_from_input)

# PAGE 2
page2 = tk.Frame(root)

title2 = tk.Label(
    page2,
    text="AI Camera 3-Camera Data Collection + OCR",
    font=("Arial", 16, "bold")
)
title2.pack(pady=5)

preview_frame = tk.Frame(
    page2,
    bg="black",
    width=640,
    height=300
)

preview_frame.pack(pady=5)
preview_frame.pack_propagate(False)

preview_label = tk.Label(preview_frame, bg="black")
preview_label.pack(fill="both", expand=True)

status_label = tk.Label(
    page2,
    text="Status: Idle",
    font=("Arial", 12)
)
status_label.pack(pady=5)

progress_label = tk.Label(
    page2,
    text="Progress: 0 / 0",
    font=("Arial", 12, "bold")
)
progress_label.pack(pady=5)

button_frame = tk.Frame(page2)
button_frame.pack(pady=5)

btn_stop = tk.Button(
    button_frame,
    text="Stop",
    font=("Arial", 14),
    width=18,
    command=stop_sequence
)
btn_stop.pack(side="left", padx=10)

root.protocol("WM_DELETE_WINDOW", on_close)

page1.pack(fill="both", expand=True)
count_entry.focus()

root.mainloop()