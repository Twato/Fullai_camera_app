# AI_CAMERA_TEST_YOLO_ROI_V4

V4 ปรับ UI:
- หน้าแรกใหม่ สวยขึ้นแบบ HMI/Test Station
- หน้า OCR Result แบบ compact table
- เห็น ROI ทุกตัว + OCR Clean + RAW + Source/Detect Conf
- ปุ่ม OK / NEXT กับ STOP อยู่ด้านบน ไม่หายแม้ผลลัพธ์เยอะ
- ยังต้องกด OK / NEXT ก่อนทำขั้นตอนต่อไป

ใช้:
1. เอา `main_test_ui.py` ไปทับไฟล์เดิม
2. รัน `python3 main_test_ui.py`
