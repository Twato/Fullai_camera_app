# AI_CAMERA_TEST_YOLO_ROI

เวอร์ชันนี้ทำตาม Flow:

Camera 1 / Camera 2:
- ยังไม่มีโมเดล
- ถ่ายภาพเต็ม
- crop กลางภาพตามค่าที่ตั้งไว้
- OCR
- แสดงผลบน UI

Camera 3 / TOC:
- เปิด USB Camera
- ใช้ YOLO detect TOC label
- ถ่ายภาพเต็ม
- เอา box ที่ YOLO detect ได้มา crop ROI
- OCR ทุก ROI ที่ detect ได้ เช่น toc, toc1, toc2, toc3...
- แสดงผลบน UI

## รัน

```bash
python main_test_ui.py
```

## ตั้งค่าโมเดล TOC

แก้ใน `config_test.py`

ถ้าไฟล์โมเดลอยู่ในโฟลเดอร์หลัก:

```python
TOC_MODEL_PATH = os.path.join(BASE_DIR, "TOC_V2.pt")
```

ถ้าอยู่ใน `models/`:

```python
TOC_MODEL_PATH = os.path.join(BASE_DIR, "models", "TOC_V2.pt")
```
