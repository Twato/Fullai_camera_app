# AI_CAMERA_TEST_YOLO_ROI_V5

V5 ใช้ logic/flow จาก V3 เดิม และปรับเฉพาะ UI หลัก:
- หน้าแรกสวยขึ้นแบบ Test Station
- หน้า Result เป็น compact table
- ยังเห็น ROI + OCR Clean + RAW + Source/DET
- ปุ่ม OK / NEXT และ STOP อยู่ด้านบน ไม่หาย
- Flow เดิมยังเหมือน V3

วิธีใช้:
1. เอา `main_test_ui.py` ไปทับไฟล์เดิมใน `/home/toto/AI_CAMERA_TEST_YOLO_ROI`
2. รัน `python3 main_test_ui.py`
