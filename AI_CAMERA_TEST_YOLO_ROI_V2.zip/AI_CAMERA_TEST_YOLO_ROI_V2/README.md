# AI_CAMERA_TEST_YOLO_ROI_V2

ไฟล์นี้เป็น main_test_ui.py เวอร์ชันแก้แล้ว

สิ่งที่เพิ่ม:
- หลัง OCR CAM1/CAM2 แล้วแสดงผลและรอปุ่ม OK / NEXT
- หลัง OCR TOC แล้วแสดงผลและรอปุ่ม OK / NEXT
- ไม่ถ่ายตัวถัดไปอัตโนมัติทันที
- ปุ่ม STOP ยังใช้ได้เหมือนเดิม

วิธีใช้:
1. เอาไฟล์ main_test_ui.py ไปแทนไฟล์เดิมใน /home/toto/AI_CAMERA_TEST_YOLO_ROI
2. รัน:
   python3 main_test_ui.py
