import os
import json
import threading
from threading import Event
from datetime import datetime
from time import sleep

import cv2
import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk

from config_test import (
    CAPTURE_DIR,
    ROI_DIR,
    OCR_DIR,
    PICAM1_INDEX,
    PICAM2_INDEX,
    USB_DEVICE,
    PREVIEW_SIZE,
    PREVIEW_INTERVAL
)

from camera_test import PiCameraTest, UsbCameraTest
from roi_test import crop_center, crop_by_box, preprocess_ocr, save_roi_files
from ocr_test import run_easyocr, load_ocr

os.makedirs(CAPTURE_DIR, exist_ok=True)
os.makedirs(ROI_DIR, exist_ok=True)
os.makedirs(OCR_DIR, exist_ok=True)

running = False
last_preview_time = 0
current_camera = None

result_ok_event = Event()

delivery_no = ""
quantity = 0
current_index = 0

def now_name(prefix):
    return datetime.now().strftime(f"{prefix}_%Y%m%d_%H%M%S_%f.jpg")

def set_status(text):
    try:
        status_label.config(text=text)
        root.update_idletasks()
    except Exception:
        pass
    print(text)

def set_step(text):
    try:
        step_label.config(text=text)
        root.update_idletasks()
    except Exception:
        pass
    print("STEP:", text)

def update_preview(frame, is_bgr=False):
    global last_preview_time

    import time
    now = time.time()

    if now - last_preview_time < PREVIEW_INTERVAL:
        return

    last_preview_time = now

    try:
        display = cv2.resize(frame, PREVIEW_SIZE)

        if is_bgr:
            display = cv2.cvtColor(display, cv2.COLOR_BGR2RGB)

        img = Image.fromarray(display)
        imgtk = ImageTk.PhotoImage(image=img)

        preview_label.imgtk = imgtk
        preview_label.config(image=imgtk, text="")

    except Exception as e:
        print("Preview error:", e)

def show_page(page):
    for p in [page_input, page_capture, page_result, page_ready_toc, page_complete]:
        p.pack_forget()
    page.pack(fill="both", expand=True)

def update_info():
    info_delivery.config(text=delivery_no or "-")
    info_qty.config(text=str(quantity or "-"))
    info_progress.config(text=f"{current_index} / {quantity}")

def set_progress(text):
    progress_label.config(text=text)
    root.update_idletasks()

def capture_path(prefix):
    return os.path.join(CAPTURE_DIR, now_name(prefix))

def process_center_roi_ocr(image_path, prefix):
    img = cv2.imread(image_path)

    if img is None:
        return {
            "image_path": image_path,
            "error": "cannot_read_image",
            "raw": "",
            "clean": ""
        }

    crop, box = crop_center(img)
    processed = preprocess_ocr(crop)
    roi_path, processed_path = save_roi_files(image_path, crop, processed, prefix)

    ocr = run_easyocr(processed)

    return {
        "name": prefix,
        "source": "center_roi",
        "image_path": image_path,
        "roi_path": roi_path,
        "processed_path": processed_path,
        "box": box,
        "raw": ocr["raw"],
        "clean": ocr["clean"],
        "items": ocr["items"]
    }

def process_yolo_roi_ocr(image_path, detections):
    img = cv2.imread(image_path)

    if img is None:
        return []

    results = []

    for det in detections:
        name = det["name"]
        box = det["box"]

        crop, fixed_box = crop_by_box(img, box, pad=0)

        if crop is None or crop.size == 0:
            continue

        processed = preprocess_ocr(crop)

        prefix = f"toc_{name}"
        roi_path, processed_path = save_roi_files(image_path, crop, processed, prefix)

        ocr = run_easyocr(processed)

        results.append({
            "name": name,
            "source": "yolo_roi",
            "detect_conf": det["conf"],
            "image_path": image_path,
            "roi_path": roi_path,
            "processed_path": processed_path,
            "box": fixed_box,
            "raw": ocr["raw"],
            "clean": ocr["clean"],
            "items": ocr["items"]
        })

    return results

def add_result_row(title, data):
    row = tk.Frame(result_list_frame, bg="#ffffff", pady=4)
    row.pack(fill="x", padx=10, pady=4)

    tk.Label(
        row,
        text=title,
        font=("Arial", 12, "bold"),
        bg="#ffffff",
        fg="#0b2a4a",
        width=18,
        anchor="w"
    ).pack(side="left")

    tk.Label(
        row,
        text=data.get("clean", ""),
        font=("Arial", 16, "bold"),
        bg="#eafaf1",
        fg="#145a32",
        width=28,
        anchor="w",
        padx=8
    ).pack(side="left", padx=6)

    extra = data.get("source", "")
    if "detect_conf" in data:
        extra += f" | DET={data['detect_conf']:.2f}"

    tk.Label(
        row,
        text=f"RAW: {data.get('raw', '')}  {extra}",
        font=("Arial", 10),
        bg="#ffffff",
        fg="#34495e",
        anchor="w"
    ).pack(side="left", padx=6)

def clear_result_list():
    for w in result_list_frame.winfo_children():
        w.destroy()

def show_product_result(product_no, cam1_data, cam2_data):
    show_page(page_result)
    result_title.config(text=f"OCR Result : Product {product_no}")
    clear_result_list()

    add_result_row("CAM1 Center ROI", cam1_data)
    add_result_row("CAM2 Center ROI", cam2_data)

    save_json({
        "type": "product",
        "product_no": product_no,
        "cam1": cam1_data,
        "cam2": cam2_data
    }, f"product_{product_no:03d}.json")

def show_toc_result(toc_items, fallback_data=None):
    show_page(page_result)
    result_title.config(text="OCR Result : TOC YOLO ROI")
    clear_result_list()

    if toc_items:
        for item in toc_items:
            add_result_row(item["name"], item)
    elif fallback_data is not None:
        add_result_row("CAM3 Center ROI", fallback_data)
    else:
        add_result_row("NO ROI", {"clean": "", "raw": "No detection"})

    save_json({
        "type": "toc",
        "toc_items": toc_items,
        "fallback": fallback_data
    }, "toc_result.json")

def save_json(data, filename):
    path = os.path.join(OCR_DIR, filename)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    print("Saved JSON:", path)

def start_job():
    global running, delivery_no, quantity, current_index

    delivery_no = delivery_entry.get().strip()
    qty_text = qty_entry.get().strip()

    if not delivery_no:
        messagebox.showwarning("Warning", "Please input Delivery No")
        return

    if not qty_text.isdigit():
        messagebox.showwarning("Warning", "Please input Quantity")
        return

    quantity = int(qty_text)

    if quantity < 1 or quantity > 100:
        messagebox.showwarning("Warning", "Quantity must be 1-100")
        return

    current_index = 0
    running = True

    update_info()
    show_page(page_capture)

    thread = threading.Thread(target=job_loop, daemon=True)
    thread.start()

def job_loop():
    global current_index, running

    set_status("Loading OCR Model...")
    load_ocr()
    set_status("OCR Ready")

    for i in range(quantity):
        if not running:
            return

        current_index = i + 1
        root.after(0, update_info)
        root.after(0, lambda i=i: set_progress(f"Product {i+1} / {quantity}"))

        ok = process_product(i + 1)

        if not ok:
            running = False
            return

        sleep(1.0)

    running = False
    root.after(0, lambda: show_page(page_ready_toc))

def process_product(product_no):
    global current_camera

    # =====================
    # CAM1
    # =====================
    root.after(0, lambda: show_page(page_capture))
    root.after(0, lambda: set_step("CAM1 : Detect object by background"))
    root.after(0, lambda: set_status("CAM1 opening"))

    cam1_path = capture_path(f"cam1_product{product_no}")

    cam1 = PiCameraTest(
        index=PICAM1_INDEX,
        name="CAM1",
        status_cb=set_status,
        preview_cb=update_preview
    )
    current_camera = cam1

    try:
        cam1.open()
        bg = cam1.wait_background(lambda: running)

        if bg is None:
            return False

        detected = cam1.wait_object(bg, lambda: running)

        if not detected:
            return False

        cam1.focus_delay(lambda: running)
        cam1.capture_file(cam1_path)

    except Exception as e:
        root.after(0, lambda: messagebox.showerror("CAM1 Error", str(e)))
        return False

    finally:
        cam1.close()
        current_camera = None

    # =====================
    # CAM2
    # =====================
    if not running:
        return False

    root.after(0, lambda: set_step("CAM2 : Capture directly"))
    root.after(0, lambda: set_status("CAM2 opening"))

    cam2_path = capture_path(f"cam2_product{product_no}")

    cam2 = PiCameraTest(
        index=PICAM2_INDEX,
        name="CAM2",
        status_cb=set_status,
        preview_cb=update_preview
    )
    current_camera = cam2

    try:
        cam2.open()
        cam2.focus_delay(lambda: running)
        cam2.capture_file(cam2_path)

    except Exception as e:
        root.after(0, lambda: messagebox.showerror("CAM2 Error", str(e)))
        return False

    finally:
        cam2.close()
        current_camera = None

    # =====================
    # OCR
    # =====================
    if not running:
        return False

    root.after(0, lambda: set_step("OCR : Center ROI CAM1/CAM2"))
    root.after(0, lambda: set_status("OCR reading"))

    cam1_data = process_center_roi_ocr(cam1_path, "cam1")
    cam2_data = process_center_roi_ocr(cam2_path, "cam2")

    root.after(0, lambda: show_product_result(product_no, cam1_data, cam2_data))

    # รอให้ผู้ใช้กด OK / NEXT ก่อนค่อยไปถ่ายตัวถัดไป
    wait_result_ok()

    return running

def continue_toc():
    global running

    running = True
    show_page(page_capture)
    update_info()

    thread = threading.Thread(target=toc_loop, daemon=True)
    thread.start()

def toc_loop():
    global running

    set_progress("TOC 1 / 1")

    ok = process_toc()

    running = False

    if ok:
        root.after(0, lambda: show_page(page_complete))

def process_toc():
    global current_camera

    root.after(0, lambda: set_step("CAM3 : YOLO detect → capture → crop ROI → OCR"))
    root.after(0, lambda: set_status("CAM3 opening"))

    toc_path = capture_path("cam3_toc")

    cam3 = UsbCameraTest(
        device=USB_DEVICE,
        name="CAM3",
        status_cb=set_status,
        preview_cb=update_preview
    )

    current_camera = cam3

    try:
        cam3.open()
        capture_result = cam3.capture_direct_or_yolo(toc_path, lambda: running)

        if not capture_result:
            return False

    except Exception as e:
        root.after(0, lambda: messagebox.showerror("CAM3 Error", str(e)))
        return False

    finally:
        cam3.close()
        current_camera = None

    image_path = capture_result["image_path"]
    detections = capture_result.get("detections", [])

    root.after(0, lambda: set_step(f"TOC OCR : YOLO ROI count = {len(detections)}"))
    root.after(0, lambda: set_status("TOC OCR reading from YOLO ROI"))

    toc_items = process_yolo_roi_ocr(image_path, detections)

    fallback = None

    if not toc_items:
        root.after(0, lambda: set_status("No YOLO ROI OCR, fallback center ROI"))
        fallback = process_center_roi_ocr(image_path, "toc_center")

    root.after(0, lambda: show_toc_result(toc_items, fallback))

    # รอให้ผู้ใช้กด OK / NEXT ก่อนค่อยจบ TOC
    wait_result_ok()

    return running

def stop_job():
    global running, current_camera

    running = False
    result_ok_event.set()

    try:
        if current_camera is not None:
            current_camera.close()
    except Exception:
        pass

    set_status("Stop Requested")

def on_result_ok():
    result_ok_event.set()


def wait_result_ok():
    result_ok_event.clear()

    while running and not result_ok_event.is_set():
        sleep(0.1)

def reset_to_input():
    global running, current_index

    running = False
    current_index = 0

    delivery_entry.delete(0, tk.END)
    qty_entry.delete(0, tk.END)

    info_delivery.config(text="-")
    info_qty.config(text="-")
    info_progress.config(text="-")

    show_page(page_input)

def on_close():
    stop_job()
    root.destroy()

# =========================================================
# UI
# =========================================================
root = tk.Tk()
root.title("AI Camera TEST UI - YOLO ROI OCR")
root.geometry("1000x680")
root.resizable(False, False)
root.configure(bg="#eef3f7")

# TOP BAR
top = tk.Frame(root, bg="#ffffff", height=88)
top.pack(side="top", fill="x")
top.pack_propagate(False)

tk.Label(
    top,
    text="AI Camera TEST UI : Capture → YOLO ROI / Center ROI → OCR",
    font=("Arial", 17, "bold"),
    bg="#ffffff",
    fg="#0b2a4a"
).pack(anchor="w", padx=18, pady=(8, 4))

info = tk.Frame(top, bg="#ffffff")
info.pack(fill="x", padx=18)

def info_box(label):
    f = tk.Frame(info, bg="#ffffff")
    f.pack(side="left", padx=(0, 40))
    tk.Label(f, text=label, bg="#ffffff", fg="#7f8c8d", font=("Arial", 9)).pack(anchor="w")
    v = tk.Label(f, text="-", bg="#ffffff", fg="#17202a", font=("Arial", 12, "bold"))
    v.pack(anchor="w")
    return v

info_delivery = info_box("Delivery No")
info_qty = info_box("Quantity")
info_progress = info_box("Progress")

# PAGE INPUT
page_input = tk.Frame(root, bg="#eef3f7")

card = tk.Frame(page_input, bg="#ffffff", padx=35, pady=35)
card.place(relx=0.5, rely=0.45, anchor="center", width=500, height=330)

tk.Label(
    card,
    text="Test Input",
    font=("Arial", 22, "bold"),
    bg="#ffffff",
    fg="#0b2a4a"
).pack(pady=(0, 20))

tk.Label(card, text="Delivery No", bg="#ffffff", font=("Arial", 11)).pack()
delivery_entry = tk.Entry(card, font=("Arial", 20), justify="center", width=22)
delivery_entry.pack(pady=6)

tk.Label(card, text="Quantity", bg="#ffffff", font=("Arial", 11)).pack(pady=(10, 0))
qty_entry = tk.Entry(card, font=("Arial", 20), justify="center", width=8)
qty_entry.pack(pady=6)

tk.Button(
    card,
    text="START TEST",
    font=("Arial", 14, "bold"),
    bg="#0b5cab",
    fg="white",
    width=18,
    command=start_job
).pack(pady=22)

# PAGE CAPTURE
page_capture = tk.Frame(root, bg="#eef3f7")

capture_title = tk.Label(
    page_capture,
    text="Capture Page",
    font=("Arial", 18, "bold"),
    bg="#eef3f7",
    fg="#0b2a4a"
)
capture_title.pack(anchor="w", padx=20, pady=(15, 5))

main_area = tk.Frame(page_capture, bg="#eef3f7")
main_area.pack(fill="both", expand=True, padx=20, pady=8)

left = tk.Frame(main_area, bg="#ffffff", padx=10, pady=10)
left.pack(side="left", fill="both", expand=True, padx=(0, 12))

preview_frame = tk.Frame(left, bg="#17202a", width=640, height=360)
preview_frame.pack()
preview_frame.pack_propagate(False)

preview_label = tk.Label(
    preview_frame,
    text="Camera Preview",
    bg="#17202a",
    fg="white",
    font=("Arial", 16)
)
preview_label.pack(fill="both", expand=True)

status_box = tk.Frame(left, bg="#f4f6f7", padx=12, pady=10)
status_box.pack(fill="x", pady=12)

tk.Label(status_box, text="Step", bg="#f4f6f7", fg="#34495e", font=("Arial", 10, "bold")).pack(anchor="w")
step_label = tk.Label(status_box, text="-", bg="#f4f6f7", fg="#17202a", font=("Arial", 13))
step_label.pack(anchor="w")

tk.Label(status_box, text="Status", bg="#f4f6f7", fg="#34495e", font=("Arial", 10, "bold")).pack(anchor="w", pady=(8, 0))
status_label = tk.Label(status_box, text="-", bg="#f4f6f7", fg="#17202a", font=("Arial", 13))
status_label.pack(anchor="w")

right = tk.Frame(main_area, bg="#ffffff", padx=15, pady=15, width=280)
right.pack(side="right", fill="y")
right.pack_propagate(False)

tk.Label(right, text="Workflow", bg="#ffffff", fg="#17202a", font=("Arial", 15, "bold")).pack(anchor="w")

for txt in [
    "1. CAM1 detect + capture",
    "2. CAM1 center ROI OCR",
    "3. CAM2 capture",
    "4. CAM2 center ROI OCR",
    "5. CAM3 YOLO detect",
    "6. CAM3 YOLO ROI OCR"
]:
    tk.Label(
        right,
        text=txt,
        bg="#f4f6f7",
        fg="#34495e",
        font=("Arial", 11),
        anchor="w",
        padx=10,
        pady=8
    ).pack(fill="x", pady=4)

progress_label = tk.Label(
    right,
    text="Product 0 / 0",
    bg="#ffffff",
    fg="#0b5cab",
    font=("Arial", 13, "bold")
)
progress_label.pack(anchor="w", pady=20)

tk.Button(
    right,
    text="STOP",
    bg="#c0392b",
    fg="white",
    font=("Arial", 12, "bold"),
    command=stop_job
).pack(side="bottom", fill="x", pady=10)

# PAGE RESULT
page_result = tk.Frame(root, bg="#eef3f7")

result_title = tk.Label(
    page_result,
    text="OCR Result",
    font=("Arial", 18, "bold"),
    bg="#eef3f7",
    fg="#0b2a4a"
)
result_title.pack(anchor="w", padx=20, pady=(20, 8))

result_list_frame = tk.Frame(page_result, bg="#ffffff", padx=10, pady=10)
result_list_frame.pack(fill="both", expand=True, padx=20, pady=10)

# ปุ่มสำหรับหยุดดูผล OCR
# ระบบจะไม่ไปขั้นตอนต่อไปจนกว่าจะกด OK / NEXT
result_button_frame = tk.Frame(page_result, bg="#eef3f7")
result_button_frame.pack(fill="x", padx=20, pady=10)

tk.Button(
    result_button_frame,
    text="OK / NEXT",
    bg="#27ae60",
    fg="white",
    font=("Arial", 12, "bold"),
    width=14,
    command=on_result_ok
).pack(side="right", padx=6)

tk.Button(
    result_button_frame,
    text="STOP",
    bg="#c0392b",
    fg="white",
    font=("Arial", 12, "bold"),
    width=14,
    command=stop_job
).pack(side="right", padx=6)

# READY TOC
page_ready_toc = tk.Frame(root, bg="#eef3f7")

toc_card = tk.Frame(page_ready_toc, bg="#ffffff", padx=35, pady=35)
toc_card.place(relx=0.5, rely=0.45, anchor="center", width=540, height=280)

tk.Label(
    toc_card,
    text="CAM1 / CAM2 Test Completed",
    font=("Arial", 21, "bold"),
    bg="#ffffff",
    fg="#229954"
).pack(pady=15)

tk.Label(
    toc_card,
    text="Press continue to test CAM3 TOC YOLO ROI OCR",
    font=("Arial", 13),
    bg="#ffffff",
    fg="#34495e"
).pack(pady=8)

tk.Button(
    toc_card,
    text="CONTINUE TO TOC",
    bg="#0b5cab",
    fg="white",
    font=("Arial", 14, "bold"),
    width=20,
    command=continue_toc
).pack(pady=20)

# COMPLETE
page_complete = tk.Frame(root, bg="#eef3f7")

complete_card = tk.Frame(page_complete, bg="#ffffff", padx=35, pady=35)
complete_card.place(relx=0.5, rely=0.45, anchor="center", width=520, height=260)

tk.Label(
    complete_card,
    text="TEST COMPLETED",
    font=("Arial", 24, "bold"),
    bg="#ffffff",
    fg="#229954"
).pack(pady=25)

tk.Button(
    complete_card,
    text="OK",
    bg="#0b5cab",
    fg="white",
    font=("Arial", 14, "bold"),
    width=16,
    command=reset_to_input
).pack(pady=10)

root.protocol("WM_DELETE_WINDOW", on_close)
show_page(page_input)
root.mainloop()
